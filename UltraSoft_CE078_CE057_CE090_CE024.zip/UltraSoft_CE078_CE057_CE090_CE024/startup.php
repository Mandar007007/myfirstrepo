<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        include 'dbconnect.php';

 $companyname=$_POST['companyname'];
 $ownername=$_POST['ownername'];
 $producttype=$_POST['producttype'];
 $currentvaluation=$_POST['currentvaluation'];
 $fundrequired=$_POST['fundrequired'];
 $description=$_POST['description'];
 $youremail=$_POST['youremail'];
 $contactnumber=$_POST['contactnumber'];
 $adderess=$_POST['adderess'];

$sql="INSERT INTO `startup` (`companyname`, `ownername`, `producttype`, `currentval`, `fund`, `disc`, `email`, `contact`, `adderess`) VALUES ('$companyname', '$ownername', '$producttype', '$currentvaluation', '$fundrequired', '$description', ' $youremail', '$contactnumber', '$adderess')";
$result=mysqli_query($conn,$sql);

        if($result)
        {
            echo"success";
        }
        else
        {
            echo "Not";
        }
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            background-image:url('https://img.freepik.com/free-photo/business-partners-handshake-global-corporate-with-technology-concept_53876-102615.jpg?w=2000');
            /* background-size:contain; */
            /* background-repeat:no-repeat; */
            min-height:100vh;
        }
         form{
            margin:35px;
        }
        .contact{
            width: 500px;
            background-color: #fff;
            box-shadow: 0 0 20px 0 #999;
            top:30px;
            left:501px;
            position: absolute;
        }
        .input{
            width:400px;
            height:40px;
            margin-top: 20px;
            padding-left: 10px;
            border:1px solid #777;
            outline: none;
            border-radius: 14px;
        }
        .btn{
            border-radius: 20px;
            color:#fff;
            margin-top: 18px;
            padding:10px;
            background-color: #47c35a;
            font-size: 12px;
            border: none;
            margin-left: 160px;
        }
    </style>
</head>
<body>
<div class="contact">
        <form action="" method="post">
            <input type="text" name="companyname" class ="input" placeholder="Company name">
            <input type="text" name="ownername"class ="input" placeholder="Owner name">
            <input type="text" name="producttype"class ="input" placeholder="Product type">
            <input type="number" name="currentvaluation"class ="input" placeholder="Current Valuation(lakhs)">
            <input type="number" name="fundrequired"class ="input" placeholder="Fund-Requried(lakhs)">
            <!-- <input type="number" class ="input" placeholder="Equity(%)"> -->
            <textarea type="text" name="description"class ="input text" placeholder="Description"></textarea>
            <input type="email" name="youremail"class ="input" placeholder="Your Email">
            <input type="tel" name="contactnumber"class ="input" placeholder="Contact Number">
            <input type="text" name="adderess"class ="input" placeholder="Adderess">
            <input type="submit" class="btn" value="REGISTER">
        </form>
    </div>
</body>
</html>