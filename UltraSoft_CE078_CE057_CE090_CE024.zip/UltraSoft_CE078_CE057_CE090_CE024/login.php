<?php
$login = false;
$showerror = false;

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    include 'dbconnect.php';
    $username=$_POST["username"];
    $password=$_POST["password"];

    $sql = "SELECT * FROM `project` WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn,$sql);
    

    $numrow = mysqli_num_rows($result);

    if($numrow == 1)
    {
        $login = true;
        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        header("location: welcome.php");
    }
    else
    {
        $showerror = "username and password does not match";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>

    .sub{
    border-radius: 50px;
}
    .con{
       
    background-color:black;
    height: 70px;
    color:white;
    width:100%;
    font-size : 23px;
    z-index: 1px;
    display:block;
    position:fixed;
    overflow:hidden;
}
        .con a
        {
            text-decoration:none;
            color:white;
            margin:31px;
            position:relative;
            top:-33px;
            font-size : 23px;
        }
.con a:hover{
    color:blue;
}
.container form{
    border-radius:46px;
}
.box{
    border-radius:46px;
}
.sub{
    margin : 28px;
}
.con{
    height: 79px;
}
</style>
<body>
<div class="con">
        <img src="pngegg.png" style="width:68px;height:68px;margin:6px;">
        <a class="bat" href="signup.php">SignUp</a>
        <a class="bat" href="login.php">Login</a>
        <!-- <a class="bat" href="logout.php">Logout</a> -->
        <a class="bat" href="signup.php">About</a>
</div>
    <div class="container">
    <form action="login.php" method="post" class = "frm">
        <label for="username" class="form-lable">Username</label>
        <input class="box" type="text" name ="username">
        <label for="password" class="form-lable">Password</label>
        <input class="box" type="password" name ="password">
        <input class = "sub" type="submit" value="login" name="submit">
    </form>
</div>
</body>
</html>