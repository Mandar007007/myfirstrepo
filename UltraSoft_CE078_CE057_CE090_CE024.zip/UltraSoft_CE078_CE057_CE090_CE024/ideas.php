<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #harm{
            height: 306px;
    position: relative;
    left: 440px;
        }
         #su{
            left:300px;
        }
        #lg{
            left:400px;
        }
        #ab{
            left:483px;
        }
        body{
            margin: 0;
            padding: 0;
            background:black;
            min-height:100vh;
        }
        #welcm{
            position: relative;
            bottom:7px;
        }
        #us{
            color:white;
            position:absolute;
            
    top: 25px;
    font-size: 27px;

        }
        #ide{
            left:570px;
        }
        .bats{
            position: relative;
            bottom:34px;
            text-decoration:none;
            font-size:21px;
            margin-left:50px;   
            color:white;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        }
        .con1{
            left: 376px;
            position: relative;
            top: 60px;
            height: 550px;
            width: 50%;
            background-color: white;
            box-shadow: 0 0 20px 0 #999;
        }

        #info{
            position: relative;
            bottom: 300px;
            line-height: 54px;
            left: 12px;
            font-family: monospace;
            font-size:23px;
        }
        #music{
            position: absolute;
    height: 500px;
    bottom: 4px;
    opacity: 0.3;
        }
        .cls{
            font-size:25px; 
        }
        .space{
            height:200px;
        }
    </style>
    
</head>
<body>
<img src="https://t3.ftcdn.net/jpg/03/21/78/20/360_F_321782058_tZ6E5kuWWcX6sgfaBGA25OCRHjkNob3X.jpg" style="width:68px;height:68px;margin:6px;">
        <span id="us">ULTRASOFT</span>
        <a class="bats" id="su" href="signup.php">SignUp</a>
        <a class="bats" id="lg" href="login.php">Login</a>
        <!-- <a class="bat" href="logout.php">Logout</a> -->
        <a class="bats" id="ab" href="signup.php">About</a>
        <a class="bats" id="ide" href="ideas.php">Ideas</a>

        <div class="con1">
        <img src="music.jpg" alt="" id="music">
        <img src="https://www.kindpng.com/picc/m/409-4092291_best-headphones-hd-png-download.png" alt="Xx" id="harm">
        <h2  id="info" style="font-size:33px;">Company Name : Microsis</h2>
        <h2 id="info" >Owner Name : Devayat Bodar</h2>
        <h2 id="info" >Product Type : Musical App</h2>
        <h2 id="info" >Current Valueation : 50 lakhs</h2>
        <h2 id="info" >Required Funds : 5 lakhs</h2>
        <!-- <h2 id="info" >Company Name : Microsis</h2> -->
        <h2 id="info" >Disc : We are a providing a musical app which is completely free of ads and will give good experience to users with fantastic UI</h2>
        <h2 id="info" >Email : devayatbodar007@gmail.com</h2>
        <h2 id="info" >Contact No : +91 7777777777</h2>
        </div>
        
        <div class="space"></div>
</body>
</html>