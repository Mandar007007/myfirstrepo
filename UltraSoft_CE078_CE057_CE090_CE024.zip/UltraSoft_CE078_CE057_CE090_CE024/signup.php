<?php
$showerror = false;
$showelert = false;
    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
        include 'dbconnect.php';
        $username = $_POST["username"];
        $password = $_POST["password"];
        $cpassword = $_POST["cpassword"];

        $existsql="SELECT * FROM `project` WHERE username = '$username'";
        $result = mysqli_query($conn,$existsql);
        $numrow = mysqli_num_rows($result);

        if($numrow > 0)
        {
            $showerror = true;
            $showerror = "USERNAME ALREADY EXIST PLEASE LOGIN..";
        }
        else
        {
            if($password == $cpassword)
            {
                $sql = "INSERT INTO `project` (`username`, `password`, `dt`) VALUES ('$username', '$password', current_timestamp())";
                $result = mysqli_query($conn,$sql);
                if($result)
                {
                    $showelert = true;
                    $showelert = "DATA HAS BEEN SUCCESSFULLY INSERTED..";
                }
                header("location:login.php");
            }
            else{
                $showerror = true;
                $showerror = "Please enter same passwords..";
            }
          
        }

    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up</title>
    <style>
          .con{
    background-color:black;
    height: 70px;
    color:white;
    width:100%;
    font-size : 23px;
    z-index: 1px;
    display:block;
    position:fixed;
    overflow:hidden;
}
        .con a
        {
            text-decoration:none;
            color:white;
            margin:31px;
            position:relative;
            top:-33px;
            font-size : 23px;
        }
        .con a:hover{
            color:blue;
        }
        .sub{
    border-radius: 50px;
}
    .container form{
        border-radius:46px;
    }
    .box{
    border-radius:46px;
}
.sub{
    margin : 40px;
}
.con{
    height: 79px;
}
        
    </style>
</head>
<body>
<div class="con">
        <img src="pngegg.png" style="width:68px;height:68px;margin:6px;">
        <a class="bat" href="signup.php">SignUp</a>
        <a class="bat" href="login.php">Login</a>
        <!-- <a class="bat" href="logout.php">Logout</a> -->
        <a class="bat" href="signup.php">About</a>
</div>
    <div class="container">
    <form action="signup.php" method="post">
        <label for="username" class="form-lable">Username</label>
        <input class="box" type="text" name ="username">
        <label for="password" class="form-lable">Password</label>
        <input class="box" type="password" name ="password">
        <label for="cpassword" class="form-lable">Confirm Password</label>
        <input class="box" type="password" name ="cpassword">
        <input class = "sub" type="submit" value="register" name="submit">
    </form>
</div>
</body>
</html>