<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* #su:hover{
            text-decoration:underline;
            /* animation-name:mandar;
            animation-duration:2s;
            animation-timing-function:ease-in; */
    
        #su{
            left:300px;
        }
        #lg{
            left:400px;
        }
        #ab{
            left:483px;
        }
        .cont{
            position: absolute;
        }
        .bats{
            position: relative;
            bottom:34px;
            text-decoration:none;
            font-size:21px;
            margin-left:50px;   
            color:white;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        }
        body{
            margin: 0;
            padding: 0;
            /* background-color:#e8e8e8; */
            
        }
        #imgs{
            width:100%;
            height:767px;
        }
        .para1 h1{
            position: absolute;
    top: 112px;
    color: white;
    left: 104px;
    line-height: 68px;
    font-size: 50px;
    font-family: monospace;
        }
        .para1 p{
            position: absolute;
    top: 334px;
    color: white;
    font-size: 18px;
    left: 104px;
    word-spacing: 5px;
    line-height:28px;
    font-family:monospace;
        }
        .para1 a{
            position: absolute;
    top: 477px;
    left: 103px;
    padding: 20px;
    font-family: cursive;
    font-size: 19px;
    text-decoration:none;
    background:white;
    color:black;
        }
        .para1 a:hover{
            background-color:#cbc2c2;
        }
        #welcm{
            position: relative;
            bottom:7px;
        }
        #us{
            color:white;
            position:absolute;
            
    top: 25px;
    font-size: 27px;

        }
        #ide{
            left:570px;
        }
 </style>
</head>
<body>
<div class="cont">
        <img src="https://t3.ftcdn.net/jpg/03/21/78/20/360_F_321782058_tZ6E5kuWWcX6sgfaBGA25OCRHjkNob3X.jpg" style="width:68px;height:68px;margin:6px;">
        <span id="us">ULTRASOFT</span>
        <!-- <a class="bats" id="su" href="signup.php">SignUp</a> -->
        <a class="bats" id="lg" href="logout.php">Logout</a>
        <!-- <a class="bat" href="logout.php">Logout</a> -->
        <a class="bats" id="ab" href="signup.php">About</a>
        <a class="bats" id="ide" href="ideas.php">Ideas</a>
</div>
<div class="imgs">
    <img id="imgs"src="https://media-www.sqspcdn.com/images/pages/vertical/small-business/hero/background-2500w.jpg" alt="">
</div>
<div class="para1">
    <h1><span id="welcm">WElCOME TO ULTRASOFT</span><br>Find Funds...<br>For Your Business</h1>
    <p>We are providing a platform for startup holders and company <br>holders for generating funds online It is a new way<br>To start your startup in very easy way. Just apply your<br> idea and get funds from well known and verified businessman<br></p>
    <a href="startup.php">GET STARTED</a>
</div>
</body>
</html>