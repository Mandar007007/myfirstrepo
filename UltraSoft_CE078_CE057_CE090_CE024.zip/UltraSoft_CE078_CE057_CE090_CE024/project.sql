-- phpMyAdmin SQL Dump
-- version 5.3.0-dev+20220608.c947f28e00
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2022 at 03:50 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `dt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `username`, `password`, `dt`) VALUES
(4, 'vivek', 'vivek', '2022-04-24 21:30:18'),
(5, 'mandar', 'mandar123', '2022-04-24 22:02:16'),
(7, 'rushi', 'rushi123', '2022-04-27 22:34:39'),
(8, 'nisarg', 'nisarg123', '2022-04-30 10:27:59'),
(9, 'neer', 'neer123', '2022-04-30 18:13:58'),
(12, 'kartik0078u', 'kartik123', '2022-05-21 15:14:38'),
(13, 'vala dhruv', 'dhruv123', '2022-05-24 21:04:14'),
(14, 'dhruv', 'dhruv123', '2022-06-03 21:05:16'),
(15, 'rajesh', 'rajesh123', '2022-06-04 00:06:46'),
(16, 'payal', 'payal123', '2022-06-06 23:44:48'),
(17, 'manav', 'manav123', '2022-06-08 10:23:51'),
(18, 'Apurva', 'apurva123', '2022-06-09 18:21:20');

-- --------------------------------------------------------

--
-- Table structure for table `startup`
--

CREATE TABLE `startup` (
  `id` int(11) NOT NULL,
  `companyname` varchar(50) NOT NULL,
  `ownername` varchar(20) NOT NULL,
  `producttype` varchar(20) NOT NULL,
  `currentval` int(20) NOT NULL,
  `fund` int(20) NOT NULL,
  `disc` varchar(500) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` int(13) NOT NULL,
  `adderess` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `startup`
--

INSERT INTO `startup` (`id`, `companyname`, `ownername`, `producttype`, `currentval`, `fund`, `disc`, `email`, `contact`, `adderess`) VALUES
(1, 'm2dtricks', 'mandar', 'it', 999, 99, 'asjdbsah', 'teamm2d007@gmail.com', 832074755, 'jayrajplot'),
(2, 'santoor', 'mandar', 'it', 12, 12, ';sdm;m', ' teamm2d007@gmail.com', 832, ';asdm;m'),
(3, 'parekh ornament', 'rajesh', 'jewellery', 50, 100, 'kjb,n.', ' rajeshparekh77@gmail.com', 2147483647, 'sonibazar'),
(4, 'Microsis', 'Devayat Bodar', 'Musical App', 50, 5, 'We are a providing a musical app which is completely free of ads and will give good experience to users with fantastic UI', ' devayatbodar007@gmail.com', 2147483647, 'Adidar Bodidar,Junagadh'),
(5, '', '', '', 0, 0, '', ' ', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `startup`
--
ALTER TABLE `startup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `startup`
--
ALTER TABLE `startup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;



